Hvordan man oversætter og kører koden:
	- Unzip mappen (code.zip)
	- Gå ind på terminalen
	- Navigere til den unzippet mappe (code/) på terminalen
	- Navigere til mappen (src/) på terminalen
	- Taste (fsharpc -a continuedFraction.fsi continuedFraction.fs) på terminalen, 
	  for at lave en (continuedFraction.dll) fil
	- (continuedFraction.dll) filen bruges til at køre en .fsx fil
	- Taste (fsharpc -r continuedFraction.dll continuedFractionTest.fsx) på terminalen
	- Taste derefter (mono continuedFractionTest.exe) på terminalen
