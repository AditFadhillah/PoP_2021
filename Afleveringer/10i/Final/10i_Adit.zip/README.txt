Hvordan man oversætter og kører koden:
	- Unzip mappen (10i_Adit.zip)
	- Gå ind på terminalen
	- Navigere til den unzippet mappe (10i_Adit/) på terminalen
	- Navigere til mappen (src/) på terminalen
	- Taste (fsharpc -a simulate.fs) på terminalen, 
	  for at lave en (simulate.dll) fil
	- For at køre testSimulate.fsx taste (fsharpc -r simulate.dll testSimulate.fsx)
	- Taste derefter (mono testSimulate.exe) på terminalen 